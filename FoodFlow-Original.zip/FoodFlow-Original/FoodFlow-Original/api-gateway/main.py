"""
API Gateway — single entry point for all client apps.
Handles: request routing to microservices, basic rate limiting,
and forwards Authorization headers for auth.
Port: 8000

Routing note (fixed):
Each backend service defines its own routes WITH the resource name
already in the path (e.g. order-service has "/orders", "/orders/{id}";
restaurant-service has "/restaurants/..." AND "/menu/..."; payment-service
has "/payments/..."; review-service has "/reviews/..."; offer-service has
"/offers/..."; notification-service has "/notify" and "/notify/log";
user-service has "/users" and "/users/{id}").
Only TWO groups are the exception — their own routes do NOT repeat the
gateway prefix, so the gateway must strip it before forwarding:
  - "auth"     -> user-service's "/register", "/login", "/me"
  - "delivery" -> delivery-service's "/partners...", "/orders/{id}/assign", "/admin/stats"
Getting this wrong (stripping everywhere) was the bug in the original
gateway — it silently 404'd on almost every real endpoint except the
few that happened to only need one path segment forwarded.
"""
import sys, os, time
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import httpx
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from shared.config import settings

app = FastAPI(title="FoodFlow - API Gateway", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# prefix -> (target_base_url, strip_prefix_before_forwarding)
SERVICE_MAP = {
    "users":       (settings.USER_SERVICE_URL, False),
    "auth":        (settings.USER_SERVICE_URL, True),   # /auth/register -> /register, /auth/login -> /login, /auth/me -> /me
    "restaurants": (settings.RESTAURANT_SERVICE_URL, False),
    "menu":        (settings.RESTAURANT_SERVICE_URL, False),
    "orders":      (settings.ORDER_SERVICE_URL, False),
    "delivery":    (settings.DELIVERY_SERVICE_URL, True),  # /delivery/partners -> /partners, etc.
    "payments":    (settings.PAYMENT_SERVICE_URL, False),
    "reviews":     (settings.REVIEW_SERVICE_URL, False),
    "notify":      (settings.NOTIFICATION_SERVICE_URL, False),
    "offers":      (settings.OFFER_SERVICE_URL, False),
}

# --- simple in-memory rate limiter (per IP) ---
RATE_LIMIT = 120         # requests
RATE_WINDOW = 60         # seconds
_request_log: dict[str, list[float]] = {}


def check_rate_limit(client_ip: str):
    now = time.time()
    window_start = now - RATE_WINDOW
    log = _request_log.setdefault(client_ip, [])
    log[:] = [t for t in log if t > window_start]
    if len(log) >= RATE_LIMIT:
        raise HTTPException(status_code=429, detail="Rate limit exceeded, slow down")
    log.append(now)


@app.get("/health")
def health():
    return {"service": "api-gateway", "status": "ok"}


@app.get("/health/all")
async def health_all():
    """Convenience check: pings every downstream service so the frontend
    can show which ones are up (helpful when running 9 processes by hand
    on Windows)."""
    results = {}
    async with httpx.AsyncClient(timeout=3.0) as client:
        seen_bases = {}
        for name, (base, _strip) in SERVICE_MAP.items():
            seen_bases[base] = seen_bases.get(base, []) + [name]
        for base, names in seen_bases.items():
            try:
                r = await client.get(f"{base}/health")
                results["/".join(sorted(set(names)))] = {"url": base, "status": r.status_code}
            except httpx.RequestError:
                results["/".join(sorted(set(names)))] = {"url": base, "status": "unreachable"}
    return results


@app.get("/admin/dashboard")
async def admin_dashboard():
    """
    Aggregates data from Order Service + Delivery Service to power
    the Operator/Admin Dashboard: total orders, revenue, delivered
    orders, active partners, top restaurants.
    NOTE: registered ABOVE the catch-all proxy routes below, otherwise
    '/admin/dashboard' would be swallowed as prefix='admin', path='dashboard'.
    """
    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            order_stats = (await client.get(f"{settings.ORDER_SERVICE_URL}/admin/stats")).json()
        except httpx.RequestError:
            order_stats = {"total_orders": 0, "delivered_orders": 0, "total_revenue": 0}
        try:
            delivery_stats = (await client.get(f"{settings.DELIVERY_SERVICE_URL}/admin/stats")).json()
        except httpx.RequestError:
            delivery_stats = {"total_partners": 0, "active_partners": 0}
        try:
            top_restaurants = (await client.get(f"{settings.ORDER_SERVICE_URL}/admin/top-restaurants")).json()
        except httpx.RequestError:
            top_restaurants = []

    return {
        "total_orders": order_stats.get("total_orders", 0),
        "delivered_orders": order_stats.get("delivered_orders", 0),
        "total_revenue": order_stats.get("total_revenue", 0),
        "active_partners": delivery_stats.get("active_partners", 0),
        "total_partners": delivery_stats.get("total_partners", 0),
        "top_restaurants": top_restaurants,
    }


async def _proxy(prefix: str, path: str, request: Request):
    check_rate_limit(request.client.host if request.client else "unknown")

    entry = SERVICE_MAP.get(prefix)
    if not entry:
        raise HTTPException(status_code=404, detail=f"No service registered for '/{prefix}'")
    target_base, strip_prefix = entry

    if strip_prefix:
        real_path = path
    else:
        real_path = f"{prefix}/{path}" if path else prefix

    target_url = f"{target_base}/{real_path}" if real_path else f"{target_base}/"

    headers = dict(request.headers)
    headers.pop("host", None)
    body = await request.body()

    async with httpx.AsyncClient() as client:
        try:
            resp = await client.request(
                request.method, target_url, headers=headers, content=body,
                params=request.query_params, timeout=15.0,
            )
        except httpx.RequestError:
            raise HTTPException(status_code=503, detail=f"Service '{prefix}' unavailable (is it running?)")

    return JSONResponse(status_code=resp.status_code, content=safe_json(resp))


@app.api_route("/{prefix}", methods=["GET", "POST", "PUT", "DELETE", "PATCH"])
async def gateway_proxy_root(prefix: str, request: Request):
    """Handles bare-resource endpoints with no trailing path segment,
    e.g. POST /orders, GET /offers, GET /users, POST /notify."""
    return await _proxy(prefix, "", request)


@app.api_route("/{prefix}/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH"])
async def gateway_proxy(prefix: str, path: str, request: Request):
    return await _proxy(prefix, path, request)


def safe_json(resp: httpx.Response):
    try:
        return resp.json()
    except ValueError:
        return {"detail": resp.text}
