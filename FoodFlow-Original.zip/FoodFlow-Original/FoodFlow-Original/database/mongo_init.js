// FoodFlow — single MongoDB database initialization.
// Every service (User, Restaurant, Order, Delivery, Payment, Review,
// Notification, Offer) now lives in this one database. Run this once
// with: mongosh < database/mongo_init.js
//
// Auto-increment integer ids (matching the ids used in JWTs and in
// cross-service calls) are generated via the "counters" collection —
// see shared/database.py:get_next_id(). You don't need to seed
// counters by hand; the first insert_one per collection creates it.

use foodflow;

// --- users (User Service) ---
db.createCollection("users");
db.users.createIndex({ id: 1 }, { unique: true });
db.users.createIndex({ email: 1 }, { unique: true });
// { id, name, email, phone, password (bcrypt hash), role, created_at }

// --- restaurants + menu_items (Restaurant Service) ---
db.createCollection("restaurants");
db.restaurants.createIndex({ id: 1 }, { unique: true });
db.restaurants.createIndex({ name: 1 });
// { id, user_id, name, address, location_lat, location_lng, image, rating, created_at }

db.createCollection("menu_items");
db.menu_items.createIndex({ id: 1 }, { unique: true });
db.menu_items.createIndex({ restaurant_id: 1 });
// { id, restaurant_id, name, description, price, image, category_id, is_available }

// --- orders (Order Service) — items embedded as an array ---
db.createCollection("orders");
db.orders.createIndex({ id: 1 }, { unique: true });
db.orders.createIndex({ user_id: 1 });
db.orders.createIndex({ restaurant_id: 1 });
db.orders.createIndex({ status: 1 });
// { id, user_id, restaurant_id, status, amount, payment_id,
//   delivery_partner_id, delivery_lat, delivery_lng, created_at,
//   items: [{ id, menu_item_id, quantity, price }] }

// --- delivery_partners (Delivery Service) ---
db.createCollection("delivery_partners");
db.delivery_partners.createIndex({ id: 1 }, { unique: true });
db.delivery_partners.createIndex({ is_available: 1 });
// { id, user_id, vehicle_type, license_no, is_available, current_lat, current_lng }

// --- payments (Payment Service) ---
db.createCollection("payments");
db.payments.createIndex({ payment_id: 1 }, { unique: true });
db.payments.createIndex({ order_id: 1 });
// { payment_id, order_id, amount, user_id, status }

// --- notifications (Notification Service) ---
db.createCollection("notifications");
db.notifications.createIndex({ sent_at: -1 });
// { channel, to, subject, message, sent_at }

// --- offers (Offer Service) ---
db.createCollection("offers");
db.offers.createIndex({ id: 1 }, { unique: true });
db.offers.createIndex({ code: 1 }, { unique: true });
// { id, code, description, discount_percent, max_discount, valid_till, is_active }

// --- reviews (Review Service) ---
db.createCollection("reviews");
db.reviews.createIndex({ restaurant_id: 1 });
db.reviews.createIndex({ order_id: 1 }, { unique: true });
// { order_id, user_id, restaurant_id, rating, comment, created_at }

// --- counters (shared auto-increment id generator, used by every service) ---
db.createCollection("counters");
// { _id: "<collection name>", seq: <int> }
