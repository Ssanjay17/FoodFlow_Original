#!/usr/bin/env python3
"""
FoodFlow - main.py
Single entry point with active 200ms file monitoring and automatic _pycache_ cleanup.
"""
import argparse
import os
import shutil
import signal
import subprocess
import sys
import threading
import time

ROOT = os.path.dirname(os.path.abspath(__file__))
PYEXE = sys.executable

SERVICES = [
    ("user-service", "services/user-service", 8001),
    ("restaurant-service", "services/restaurant-service", 8002),
    ("order-service", "services/order-service", 8003),
    ("delivery-service", "services/delivery-service", 8004),
    ("payment-service", "services/payment-service", 8005),
    ("review-service", "services/review-service", 8006),
    ("notification-service", "services/notification-service", 8007),
    ("offer-service", "services/offer-service", 8008),
]
GATEWAY = ("api-gateway", "api-gateway", 8000)
FRONTEND_PORT = 3000

processes = {}
shutdown_event = threading.Event()


def clean_pycache():
    """Recursively deletes every _pycache_ folder in the project."""
    print("Clearing all _pycache_ directories...")
    for root, dirs, _files in os.walk(ROOT):
        for d in dirs:
            if d == "_pycache_":
                path = os.path.join(root, d)
                try:
                    shutil.rmtree(path)
                    print(f"  Removed: {os.path.relpath(path, ROOT)}")
                except OSError:
                    pass


def check_required_files():
    """Checks if every service main.py file exists on disk."""
    for _name, rel_path, _port in SERVICES + [GATEWAY]:
        target = os.path.join(ROOT, rel_path, "main.py")
        if not os.path.exists(target):
            return os.path.join(rel_path, "main.py")
    return None


def force_kill_all():
    """Force terminates all child processes and cleans up _pycache_."""
    if shutdown_event.is_set():
        return
    shutdown_event.set()

    print("\n[CRITICAL] Shutting down all services immediately...")
    for name, proc in list(processes.items()):
        if proc and proc.poll() is None:
            try:
                if sys.platform.startswith("win"):
                    subprocess.call(
                        ["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    )
                else:
                    proc.kill()
            except OSError:
                pass

    clean_pycache()
    print("All services stopped and project cleaned.")
    os._exit(1)


def file_and_process_watcher():
    """Polls disk every 200ms to detect file deletions or process crashes."""
    while not shutdown_event.is_set():
        # 1. Live disk check: check if any main.py is missing/deleted
        missing = check_required_files()
        if missing:
            print(f"\n[ALERT] Service file deleted or missing: '{missing}'")
            force_kill_all()
            break

        # 2. Process check: check if any microservice died
        for name, proc in list(processes.items()):
            if proc.poll() is not None:
                print(f"\n[ALERT] Service '{name}' stopped unexpectedly.")
                force_kill_all()
                break

        time.sleep(0.2)


def spawn(name, rel_path, port, is_frontend=False):
    cwd = os.path.join(ROOT, rel_path)
    env = os.environ.copy()
    existing_pp = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = ROOT + (os.pathsep + existing_pp if existing_pp else "")

    if is_frontend:
        cmd = [PYEXE, "-m", "http.server", str(port)]
    else:
        cmd = [
            PYEXE,
            "-m",
            "uvicorn",
            "main:app",
            "--host",
            "0.0.0.0",
            "--port",
            str(port),
        ]

    proc = subprocess.Popen(cmd, cwd=cwd, env=env)
    processes[name] = proc


def install_dependencies():
    print("=== Installing requirements.txt ===")
    req_path = os.path.join(ROOT, "requirements.txt")
    if os.path.exists(req_path):
        subprocess.check_call([PYEXE, "-m", "pip", "install", "-r", req_path])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-install", action="store_true", help="Skip pip install step")
    args = parser.parse_args()

    if not args.no_install:
        install_dependencies()

    # Initial layout check
    missing = check_required_files()
    if missing:
        print(f"ERROR: Cannot start. Missing required file: {missing}")
        clean_pycache()
        sys.exit(1)

    print("\nStarting microservices...")
    for name, rel_path, port in SERVICES:
        spawn(name, rel_path, port)

    time.sleep(2)
    print("Starting API Gateway...")
    spawn(GATEWAY[0], GATEWAY[1], GATEWAY[2])

    print("Starting Frontend...")
    spawn("frontend", "frontend", FRONTEND_PORT, is_frontend=True)

    # Register OS kill signals
    signal.signal(signal.SIGINT, lambda *args: force_kill_all())
    signal.signal(signal.SIGTERM, lambda *args: force_kill_all())

    # Start active background monitor thread
    watcher = threading.Thread(target=file_and_process_watcher, daemon=True)
    watcher.start()

    print("\nAll services running. Active file watcher is LIVE (200ms check interval).")
    print("If you delete any service main.py, all services will shut down instantly.\n")

    while True:
        time.sleep(1)


if __name__ == "__main__":
    main()