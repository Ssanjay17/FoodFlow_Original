"""
Delivery Service — Partner assignment + Real-time location tracking.
Implements Section 5 of the architecture: WebSocket + Redis Pub/Sub
for live order tracking, updated every few seconds.
Data (partners) lives in MongoDB; Redis is kept ONLY as the pub/sub
message broker for the WebSocket tracking layer — it is not a database.
Port: 8004
"""
import sys, os, json, asyncio
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

import httpx
import redis
from fastapi import FastAPI, Depends, HTTPException, WebSocket, WebSocketDisconnect
from pymongo.database import Database

from shared.database import get_db, get_next_id
from shared.auth import get_current_user, require_role
from shared.config import settings

from models import COLLECTION, ensure_indexes
from schemas import PartnerCreate, PartnerOut, LocationUpdate, CompleteDelivery

app = FastAPI(title="FoodFlow - Delivery Service", version="1.0.0")
ensure_indexes(get_db())

redis_client = redis.Redis(host=settings.REDIS_HOST, port=settings.REDIS_PORT, decode_responses=True)


@app.get("/health")
def health():
    return {"service": "delivery-service", "status": "ok"}


@app.post("/partners", response_model=PartnerOut)
def register_partner(payload: PartnerCreate, current=Depends(require_role("delivery")), db: Database = Depends(get_db)):
    partner_id = get_next_id(db, COLLECTION)
    doc = {
        "id": partner_id,
        "user_id": int(current["sub"]),
        "is_available": True,
        "current_lat": None,
        "current_lng": None,
        "current_order_id": None,
        **payload.dict(),
    }
    db[COLLECTION].insert_one(doc)
    return doc


@app.get("/partners/available", response_model=list[PartnerOut])
def available_partners(db: Database = Depends(get_db)):
    return list(db[COLLECTION].find({"is_available": True}))


@app.get("/partners", response_model=list[PartnerOut])
def all_partners(db: Database = Depends(get_db)):
    """Admin view: every registered delivery partner, available or busy."""
    return list(db[COLLECTION].find({}))


@app.get("/partners/me", response_model=PartnerOut)
def my_partner_profile(current=Depends(require_role("delivery")), db: Database = Depends(get_db)):
    """The logged-in delivery partner's own profile (no need to remember an ID)."""
    partner = db[COLLECTION].find_one({"user_id": int(current["sub"])})
    if not partner:
        raise HTTPException(status_code=404, detail="Not registered as a delivery partner yet")
    return partner


@app.get("/partners/{partner_id}", response_model=PartnerOut)
def get_partner(partner_id: int, db: Database = Depends(get_db)):
    partner = db[COLLECTION].find_one({"id": partner_id})
    if not partner:
        raise HTTPException(status_code=404, detail="Partner not found")
    return partner


@app.post("/orders/{order_id}/assign")
def assign_order(order_id: int, partner_id: int | None = None, db: Database = Depends(get_db)):
    """
    Order Flow Step 5: partner assigned to a delivery.
    If partner_id is given (admin picked a specific, available partner from
    the list), assign that one. Otherwise pick the first available partner.
    A partner who just completed a delivery is available again here, so
    admins can reassign them to a new order.
    """
    query = {"id": partner_id, "is_available": True} if partner_id is not None else {"is_available": True}
    partner = db[COLLECTION].find_one_and_update(
        query, {"$set": {"is_available": False, "current_order_id": order_id}}
    )
    if not partner:
        detail = "That partner is not available" if partner_id is not None else "No delivery partners available"
        raise HTTPException(status_code=404, detail=detail)

    try:
        httpx.put(
            f"{settings.ORDER_SERVICE_URL}/orders/{order_id}/assign-delivery",
            params={"delivery_partner_id": partner["id"]}, timeout=5,
        )
    except httpx.RequestError:
        pass

    return {"order_id": order_id, "delivery_partner_id": partner["id"]}


@app.post("/partners/{partner_id}/pickup/{order_id}")
def pickup_order(partner_id: int, order_id: int, current=Depends(require_role("delivery")), db: Database = Depends(get_db)):
    """
    Delivery partner self-service: claim an unassigned order by clicking
    'Pick up' — no admin dispatch needed. Atomically claims the partner
    (must be free) and the order (must be unassigned), then marks the
    order 'picked_up' directly since the partner is taking it now.
    """
    partner = db[COLLECTION].find_one({"id": partner_id})
    if not partner:
        raise HTTPException(status_code=404, detail="Partner not found")
    if partner["user_id"] != int(current["sub"]):
        raise HTTPException(status_code=403, detail="This isn't your delivery partner profile")

    claimed = db[COLLECTION].find_one_and_update(
        {"id": partner_id, "is_available": True},
        {"$set": {"is_available": False, "current_order_id": order_id}},
    )
    if not claimed:
        raise HTTPException(status_code=400, detail="You're already on a delivery")

    try:
        httpx.put(
            f"{settings.ORDER_SERVICE_URL}/orders/{order_id}/assign-delivery",
            params={"delivery_partner_id": partner_id}, timeout=5,
        )
        httpx.put(
            f"{settings.ORDER_SERVICE_URL}/orders/{order_id}/status",
            json={"status": "picked_up"}, timeout=5,
        )
    except httpx.RequestError:
        pass

    return {"order_id": order_id, "delivery_partner_id": partner_id, "status": "picked_up"}


@app.put("/partners/{partner_id}/location")
def update_location(partner_id: int, payload: LocationUpdate, db: Database = Depends(get_db)):
    """
    Delivery partner clicks "Send location" (or the app calls this every
    few seconds). This is the one place a partner's current position is
    written, so it's what admin, the restaurant owner, and the customer
    all read from (via GET /partners/{id}, polled by the frontend) to
    see the partner's current location for an order.

    Always persists to MongoDB first - that's what admin/owner/customer
    read from - then best-effort publishes to Redis Pub/Sub for the
    optional WebSocket tracking channel. Redis being down (it's an
    optional dependency, see README) must never block a location update.
    """
    partner = db[COLLECTION].find_one_and_update(
        {"id": partner_id},
        {"$set": {"current_lat": payload.lat, "current_lng": payload.lng}},
    )
    if not partner:
        raise HTTPException(status_code=404, detail="Partner not found")

    try:
        redis_client.publish(
            f"tracking:{partner_id}",
            json.dumps({"lat": payload.lat, "lng": payload.lng, "order_id": partner.get("current_order_id")}),
        )
    except redis.exceptions.RedisError:
        pass  # Redis is optional - live location for admin/owner/customer still works via polling

    return {
        "partner_id": partner_id,
        "lat": payload.lat,
        "lng": payload.lng,
        "order_id": partner.get("current_order_id"),
    }


@app.put("/partners/{partner_id}/complete-delivery")
def complete_delivery(partner_id: int, payload: CompleteDelivery, current=Depends(require_role("delivery")), db: Database = Depends(get_db)):
    """
    Partner marks a delivery complete. This:
    1. Tells the Order Service to flip the order to 'delivered'.
    2. Frees the partner (is_available=True, current_order_id cleared) so
       an admin can immediately reassign them to a new order.
    """
    partner = db[COLLECTION].find_one({"id": partner_id})
    if not partner:
        raise HTTPException(status_code=404, detail="Partner not found")
    if partner["user_id"] != int(current["sub"]):
        raise HTTPException(status_code=403, detail="This isn't your delivery partner profile")

    try:
        httpx.put(
            f"{settings.ORDER_SERVICE_URL}/orders/{payload.order_id}/status",
            json={"status": "delivered"}, timeout=5,
        )
    except httpx.RequestError:
        pass

    partner = db[COLLECTION].find_one_and_update(
        {"id": partner_id}, {"$set": {"is_available": True, "current_order_id": None}}
    )
    return {"partner_id": partner_id, "order_id": payload.order_id, "is_available": True, "status": "delivered"}


@app.websocket("/ws/track/{partner_id}")
async def track_partner(websocket: WebSocket, partner_id: int):
    """
    Real-time tracking: User's app opens this WebSocket connection
    to receive live location updates every few seconds (Section 5).
    """
    await websocket.accept()
    pubsub = redis_client.pubsub()
    pubsub.subscribe(f"tracking:{partner_id}")

    try:
        while True:
            message = pubsub.get_message(timeout=2.0)
            if message and message["type"] == "message":
                await websocket.send_text(message["data"])
            await asyncio.sleep(1)
    except WebSocketDisconnect:
        pubsub.unsubscribe(f"tracking:{partner_id}")


@app.get("/admin/stats")
def delivery_stats(db: Database = Depends(get_db)):
    """Feeds the Operator/Admin Dashboard (Section 7): active delivery partners."""
    total_partners = db[COLLECTION].count_documents({})
    active_partners = db[COLLECTION].count_documents({"is_available": True})
    return {"total_partners": total_partners, "active_partners": active_partners}
