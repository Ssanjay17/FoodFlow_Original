"""
MongoDB collection for the Delivery Service.

Document shape (collection: "delivery_partners"):
{
    "id": int,
    "user_id": int,
    "vehicle_type": str | None,
    "license_no": str | None,
    "is_available": bool,
    "current_lat": float | None,
    "current_lng": float | None,
    "current_order_id": int | None,
}
"""
from pymongo.database import Database

COLLECTION = "delivery_partners"


def ensure_indexes(db: Database):
    db[COLLECTION].create_index("id", unique=True)
    db[COLLECTION].create_index("is_available")
