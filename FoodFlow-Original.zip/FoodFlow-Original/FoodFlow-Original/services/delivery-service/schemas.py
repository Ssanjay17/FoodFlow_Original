from pydantic import BaseModel
from typing import Optional

class PartnerCreate(BaseModel):
    vehicle_type: str
    license_no: str

class PartnerOut(BaseModel):
    id: int
    user_id: int
    vehicle_type: Optional[str]
    license_no: Optional[str]
    is_available: bool
    current_lat: Optional[float]
    current_lng: Optional[float]
    current_order_id: Optional[int] = None

    class Config:
        from_attributes = True

class LocationUpdate(BaseModel):
    lat: float
    lng: float

class CompleteDelivery(BaseModel):
    order_id: int
