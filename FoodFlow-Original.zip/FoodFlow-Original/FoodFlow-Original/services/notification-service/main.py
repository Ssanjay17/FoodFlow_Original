"""
Notification Service — Email / SMS / Push notifications.
Mocks providers (SendGrid/Twilio/FCM) — plug in real credentials when ready.
Sent notifications are now logged to MongoDB (collection: "notifications")
instead of an in-memory list, for full single-database consistency.
Port: 8007
"""
import sys, os
from datetime import datetime
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from fastapi import FastAPI, Depends
from pydantic import BaseModel
from typing import Optional, Literal
from pymongo.database import Database

from shared.database import get_db

app = FastAPI(title="FoodFlow - Notification Service", version="1.0.0")

COLLECTION = "notifications"


class NotificationRequest(BaseModel):
    channel: Literal["email", "sms", "push"]
    to: str
    subject: Optional[str] = None
    message: str


@app.get("/health")
def health():
    return {"service": "notification-service", "status": "ok"}


@app.post("/notify")
def send_notification(payload: NotificationRequest, db: Database = Depends(get_db)):
    """
    Called by other services (Order, Delivery, Payment) at key events:
    order confirmed, delivery assigned, order delivered, payment failed, etc.
    """
    entry = payload.dict()
    entry["sent_at"] = datetime.utcnow()
    db[COLLECTION].insert_one(entry)

    # TODO: Replace with real SendGrid / Twilio / FCM calls in production:
    # if payload.channel == "email": sendgrid_client.send(...)
    # if payload.channel == "sms": twilio_client.messages.create(...)
    # if payload.channel == "push": fcm_client.send(...)

    print(f"[NOTIFY][{payload.channel.upper()}] -> {payload.to}: {payload.message}")
    return {"status": "queued", "channel": payload.channel, "to": payload.to}


@app.get("/notify/log")
def get_log(db: Database = Depends(get_db)):
    docs = list(db[COLLECTION].find({}, {"_id": 0}).sort("sent_at", -1).limit(50))
    docs.reverse()
    return docs
