"""
Offer Service — Coupons, discounts.
Port: 8008
"""
import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from fastapi import FastAPI, Depends, HTTPException
from pymongo.database import Database

from shared.database import get_db, get_next_id
from shared.auth import require_role

from models import COLLECTION, ensure_indexes
from schemas import OfferCreate, OfferOut

app = FastAPI(title="FoodFlow - Offer Service", version="1.0.0")
ensure_indexes(get_db())


@app.get("/health")
def health():
    return {"service": "offer-service", "status": "ok"}


@app.post("/offers", response_model=OfferOut)
def create_offer(payload: OfferCreate, current=Depends(require_role("admin")), db: Database = Depends(get_db)):
    if db[COLLECTION].find_one({"code": payload.code}):
        raise HTTPException(status_code=400, detail="Offer code already exists")
    offer_id = get_next_id(db, COLLECTION)
    doc = {
        "id": offer_id,
        "is_active": True,
        **payload.dict(),
    }
    db[COLLECTION].insert_one(doc)
    return doc


@app.get("/offers", response_model=list[OfferOut])
def list_offers(db: Database = Depends(get_db)):
    return list(db[COLLECTION].find({"is_active": True}))


@app.get("/offers/{code}", response_model=OfferOut)
def get_offer(code: str, db: Database = Depends(get_db)):
    offer = db[COLLECTION].find_one({"code": code, "is_active": True})
    if not offer:
        raise HTTPException(status_code=404, detail="Offer not found or inactive")
    return offer


@app.delete("/offers/{code}")
def deactivate_offer(code: str, current=Depends(require_role("admin")), db: Database = Depends(get_db)):
    offer = db[COLLECTION].find_one_and_update(
        {"code": code}, {"$set": {"is_active": False}}
    )
    if not offer:
        raise HTTPException(status_code=404, detail="Offer not found")
    return {"code": code, "is_active": False}
