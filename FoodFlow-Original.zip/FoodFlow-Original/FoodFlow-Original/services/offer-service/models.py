"""
MongoDB collection for the Offer Service.

Document shape (collection: "offers"):
{
    "id": int,
    "code": str,               # unique
    "description": str | None,
    "discount_percent": float,
    "max_discount": float | None,
    "valid_till": datetime | None,
    "is_active": bool,
}
"""
from pymongo.database import Database

COLLECTION = "offers"


def ensure_indexes(db: Database):
    db[COLLECTION].create_index("id", unique=True)
    db[COLLECTION].create_index("code", unique=True)
