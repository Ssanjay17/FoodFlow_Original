from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class OfferCreate(BaseModel):
    code: str
    description: Optional[str] = None
    discount_percent: float
    max_discount: Optional[float] = None
    valid_till: Optional[datetime] = None

class OfferOut(BaseModel):
    id: int
    code: str
    description: Optional[str]
    discount_percent: float
    max_discount: Optional[float]
    valid_till: Optional[datetime]
    is_active: bool

    class Config:
        from_attributes = True
