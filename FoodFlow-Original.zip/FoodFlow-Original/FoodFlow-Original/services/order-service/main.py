"""
Order Service — Order creation, tracking, status flow.
Orchestrates calls to Payment, Delivery, Notification services (steps 1-8 of Order Flow).
Port: 8003
"""
import sys, os
from datetime import datetime
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

import httpx
from fastapi import FastAPI, Depends, HTTPException
from pymongo import ReturnDocument
from pymongo.database import Database

from shared.database import get_db, get_next_id
from shared.auth import get_current_user, require_role
from shared.config import settings

from models import COLLECTION, ensure_indexes
from schemas import OrderCreate, OrderOut, StatusUpdate

app = FastAPI(title="FoodFlow - Order Service", version="1.0.0")
ensure_indexes(get_db())


@app.get("/health")
def health():
    return {"service": "order-service", "status": "ok"}


@app.post("/orders", response_model=OrderOut)
def place_order(payload: OrderCreate, current=Depends(get_current_user), db: Database = Depends(get_db)):
    """
    Order Flow Step 1-3:
    1. User places order
    2. Validate (basic: items must exist)
    3. Trigger payment processing
    """
    if not payload.items:
        raise HTTPException(status_code=400, detail="Order must contain at least one item")

    amount = sum(i.price * i.quantity for i in payload.items)

    # Apply offer if provided
    if payload.offer_code:
        try:
            resp = httpx.get(f"{settings.OFFER_SERVICE_URL}/offers/{payload.offer_code}", timeout=5)
            if resp.status_code == 200:
                offer = resp.json()
                discount = min(amount * float(offer["discount_percent"]) / 100, float(offer.get("max_discount") or amount))
                amount = round(amount - discount, 2)
        except httpx.RequestError:
            pass  # offer service unavailable, proceed without discount

    order_id = get_next_id(db, COLLECTION)
    items = [
        {"id": idx + 1, "menu_item_id": i.menu_item_id, "quantity": i.quantity, "price": i.price}
        for idx, i in enumerate(payload.items)
    ]
    doc = {
        "id": order_id,
        "user_id": int(current["sub"]),
        "restaurant_id": payload.restaurant_id,
        "status": "placed",
        "amount": amount,
        "payment_id": None,
        "delivery_partner_id": None,
        "delivery_lat": payload.delivery_lat,
        "delivery_lng": payload.delivery_lng,
        "delivery_address": payload.delivery_address,
        "created_at": datetime.utcnow(),
        "delivered_at": None,
        "items": items,
    }
    db[COLLECTION].insert_one(doc)

    # Step 3: kick off payment (Payment Service processes payment)
    try:
        httpx.post(f"{settings.PAYMENT_SERVICE_URL}/payments", json={
            "order_id": order_id, "amount": float(amount), "user_id": int(current["sub"])
        }, timeout=5)
    except httpx.RequestError:
        pass  # payment service unreachable; order stays 'placed' until retried

    doc = db[COLLECTION].find_one({"id": order_id})
    return doc


@app.get("/orders/all", response_model=list[OrderOut])
def list_all_orders(current=Depends(require_role("admin")), db: Database = Depends(get_db)):
    """Admin-only: every order in the system, newest first."""
    return list(db[COLLECTION].find({}).sort("id", -1))


@app.get("/orders/restaurant/{restaurant_id}", response_model=list[OrderOut])
def list_orders_for_restaurant(restaurant_id: int, db: Database = Depends(get_db)):
    """Restaurant owner view: every order placed for this restaurant."""
    return list(db[COLLECTION].find({"restaurant_id": restaurant_id}).sort("id", -1))


@app.get("/orders/partner/{partner_id}", response_model=list[OrderOut])
def list_orders_for_partner(partner_id: int, db: Database = Depends(get_db)):
    """Delivery partner view: every order ever assigned to this partner
    (current + past deliveries), newest first."""
    return list(db[COLLECTION].find({"delivery_partner_id": partner_id}).sort("id", -1))


@app.get("/orders/unassigned", response_model=list[OrderOut])
def list_unassigned_orders(db: Database = Depends(get_db)):
    """Delivery partner view: orders placed by customers that no partner
    has picked up yet — shown with a 'Pick up' button."""
    return list(db[COLLECTION].find({
        "delivery_partner_id": None,
        "status": {"$in": ["placed", "confirmed"]},
    }).sort("id", -1))


@app.get("/orders/{order_id}", response_model=OrderOut)
def get_order(order_id: int, db: Database = Depends(get_db)):
    order = db[COLLECTION].find_one({"id": order_id})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return order


@app.get("/orders", response_model=list[OrderOut])
def list_my_orders(current=Depends(get_current_user), db: Database = Depends(get_db)):
    return list(db[COLLECTION].find({"user_id": int(current["sub"])}))


@app.put("/orders/{order_id}/status", response_model=OrderOut)
def update_status(order_id: int, payload: StatusUpdate, db: Database = Depends(get_db)):
    """
    Used internally by Payment Service (confirmed), Delivery Service
    (assigned / picked_up / delivered). No end-user JWT is available on
    these service-to-service calls, so this route is intentionally open
    like /orders/{id}/assign-delivery.
    """
    update = {"status": payload.status}
    if payload.status == "delivered":
        update["delivered_at"] = datetime.utcnow()
    order = db[COLLECTION].find_one_and_update(
        {"id": order_id}, {"$set": update}, return_document=ReturnDocument.AFTER
    )
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return order


@app.put("/orders/{order_id}/assign-delivery")
def assign_delivery(order_id: int, delivery_partner_id: int, db: Database = Depends(get_db)):
    order = db[COLLECTION].find_one_and_update(
        {"id": order_id},
        {"$set": {"delivery_partner_id": delivery_partner_id, "status": "assigned"}},
    )
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return {"order_id": order_id, "delivery_partner_id": delivery_partner_id, "status": "assigned"}


@app.get("/admin/stats")
def order_stats(db: Database = Depends(get_db)):
    """Feeds the Operator/Admin Dashboard (Section 7): total orders, revenue, delivered orders."""
    total_orders = db[COLLECTION].count_documents({})
    delivered_orders = db[COLLECTION].count_documents({"status": "delivered"})
    revenue_cursor = db[COLLECTION].aggregate([
        {"$match": {"status": {"$ne": "cancelled"}}},
        {"$group": {"_id": None, "total": {"$sum": "$amount"}}},
    ])
    revenue_doc = next(revenue_cursor, None)
    revenue_sum = float(revenue_doc["total"]) if revenue_doc else 0.0
    return {
        "total_orders": total_orders,
        "delivered_orders": delivered_orders,
        "total_revenue": revenue_sum,
    }


@app.get("/admin/top-restaurants")
def top_restaurants(db: Database = Depends(get_db), limit: int = 5):
    results = db[COLLECTION].aggregate([
        {"$group": {"_id": "$restaurant_id", "order_count": {"$sum": 1}}},
        {"$sort": {"order_count": -1}},
        {"$limit": limit},
    ])
    return [{"restaurant_id": r["_id"], "order_count": r["order_count"]} for r in results]
