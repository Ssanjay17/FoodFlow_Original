"""
MongoDB collection for the Order Service.

Order items are embedded directly in the order document (more idiomatic
in MongoDB than a separate join table/collection).

Document shape (collection: "orders"):
{
    "id": int,
    "user_id": int,
    "restaurant_id": int,
    "status": str,             # placed, confirmed, payment_failed, assigned, picked_up, delivered, cancelled
    "amount": float,
    "payment_id": str | None,
    "delivery_partner_id": int | None,
    "delivery_lat": float | None,
    "delivery_lng": float | None,
    "created_at": datetime,
    "items": [
        {"id": int, "menu_item_id": int, "quantity": int, "price": float},
        ...
    ],
}
"""
from pymongo.database import Database

COLLECTION = "orders"


def ensure_indexes(db: Database):
    db[COLLECTION].create_index("id", unique=True)
    db[COLLECTION].create_index("user_id")
    db[COLLECTION].create_index("restaurant_id")
    db[COLLECTION].create_index("status")
