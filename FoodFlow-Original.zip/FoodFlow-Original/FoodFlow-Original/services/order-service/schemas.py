from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

class OrderItemIn(BaseModel):
    menu_item_id: int
    quantity: int
    price: float

class OrderCreate(BaseModel):
    restaurant_id: int
    items: List[OrderItemIn]
    delivery_lat: Optional[float] = None
    delivery_lng: Optional[float] = None
    delivery_address: Optional[str] = None
    offer_code: Optional[str] = None

class OrderItemOut(OrderItemIn):
    id: int
    class Config:
        from_attributes = True

class OrderOut(BaseModel):
    id: int
    user_id: int
    restaurant_id: int
    status: str
    amount: float
    payment_id: Optional[str]
    delivery_partner_id: Optional[int]
    delivery_lat: Optional[float]
    delivery_lng: Optional[float]
    delivery_address: Optional[str] = None
    created_at: datetime
    delivered_at: Optional[datetime] = None
    items: List[OrderItemOut] = []

    class Config:
        from_attributes = True

class StatusUpdate(BaseModel):
    status: str
