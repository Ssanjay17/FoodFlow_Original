"""
Payment Service — Payments, refunds.
Mocks a payment gateway (Razorpay/Stripe) — swap the mock function
for a real SDK call when you're ready to go live.
Payments are now persisted in MongoDB (collection: "payments") instead
of an in-memory dict, for full single-database consistency and audit.
Port: 8005
"""
import sys, os, uuid, random
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

import httpx
from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
from pymongo.database import Database

from shared.config import settings
from shared.database import get_db

app = FastAPI(title="FoodFlow - Payment Service", version="1.0.0")

COLLECTION = "payments"


@app.on_event("startup")
def ensure_indexes():
    get_db()[COLLECTION].create_index("payment_id", unique=True)


class PaymentRequest(BaseModel):
    order_id: int
    amount: float
    user_id: int


class RefundRequest(BaseModel):
    payment_id: str


@app.get("/health")
def health():
    return {"service": "payment-service", "status": "ok"}


def mock_gateway_charge(amount: float) -> bool:
    """Simulates a payment gateway call. Replace with real Razorpay/Stripe SDK."""
    return random.random() > 0.05  # 95% success rate for demo


@app.post("/payments")
def process_payment(payload: PaymentRequest, db: Database = Depends(get_db)):
    """
    Order Flow Step 3: Payment Service processes payment (success/failure handling)
    """
    payment_id = f"pay_{uuid.uuid4().hex[:12]}"
    success = mock_gateway_charge(payload.amount)

    db[COLLECTION].insert_one({
        "payment_id": payment_id,
        "order_id": payload.order_id,
        "amount": payload.amount,
        "user_id": payload.user_id,
        "status": "success" if success else "failed",
    })

    new_status = "confirmed" if success else "payment_failed"
    try:
        httpx.put(
            f"{settings.ORDER_SERVICE_URL}/orders/{payload.order_id}/status",
            json={"status": new_status}, timeout=5,
        )
    except httpx.RequestError:
        pass

    if not success:
        raise HTTPException(status_code=402, detail="Payment failed")

    return {"payment_id": payment_id, "status": "success"}


@app.get("/payments/{payment_id}")
def get_payment(payment_id: str, db: Database = Depends(get_db)):
    payment = db[COLLECTION].find_one({"payment_id": payment_id}, {"_id": 0})
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")
    return payment


@app.post("/payments/refund")
def refund(payload: RefundRequest, db: Database = Depends(get_db)):
    payment = db[COLLECTION].find_one_and_update(
        {"payment_id": payload.payment_id}, {"$set": {"status": "refunded"}}
    )
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")
    return {"payment_id": payload.payment_id, "status": "refunded"}
