"""
Restaurant Service — Restaurant management + Menu catalog
Port: 8002
"""
import sys, os
from datetime import datetime
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from fastapi import FastAPI, Depends, HTTPException, Query
from pymongo.database import Database

from shared.database import get_db, get_next_id
from shared.auth import get_current_user, require_role

from models import RESTAURANTS_COLLECTION, MENU_ITEMS_COLLECTION, ensure_indexes
from schemas import RestaurantCreate, RestaurantOut, RestaurantUpdate, MenuItemCreate, MenuItemOut

app = FastAPI(title="FoodFlow - Restaurant Service", version="1.0.0")
ensure_indexes(get_db())


@app.get("/health")
def health():
    return {"service": "restaurant-service", "status": "ok"}


@app.post("/restaurants", response_model=RestaurantOut)
def create_restaurant(payload: RestaurantCreate, current=Depends(require_role("restaurant", "admin")), db: Database = Depends(get_db)):
    restaurant_id = get_next_id(db, RESTAURANTS_COLLECTION)
    doc = {
        "id": restaurant_id,
        "user_id": int(current["sub"]),
        "rating": 0,
        "created_at": datetime.utcnow(),
        **payload.dict(),
    }
    db[RESTAURANTS_COLLECTION].insert_one(doc)
    return doc


@app.get("/restaurants", response_model=list[RestaurantOut])
def list_restaurants(search: str | None = Query(None), db: Database = Depends(get_db)):
    query = {}
    if search:
        query["name"] = {"$regex": search, "$options": "i"}
    return list(db[RESTAURANTS_COLLECTION].find(query))


@app.get("/restaurants/{restaurant_id}", response_model=RestaurantOut)
def get_restaurant(restaurant_id: int, db: Database = Depends(get_db)):
    r = db[RESTAURANTS_COLLECTION].find_one({"id": restaurant_id})
    if not r:
        raise HTTPException(status_code=404, detail="Restaurant not found")
    return r


@app.put("/restaurants/{restaurant_id}", response_model=RestaurantOut)
def update_restaurant(restaurant_id: int, payload: RestaurantUpdate, current=Depends(require_role("restaurant", "admin")), db: Database = Depends(get_db)):
    """Owner-only (or admin): edit a restaurant's card image/name/address.
    A restaurant owner may only edit their own restaurant."""
    r = db[RESTAURANTS_COLLECTION].find_one({"id": restaurant_id})
    if not r:
        raise HTTPException(status_code=404, detail="Restaurant not found")
    if current.get("role") != "admin" and r.get("user_id") != int(current["sub"]):
        raise HTTPException(status_code=403, detail="You can only edit your own restaurant")

    update = {k: v for k, v in payload.dict().items() if v is not None}
    if update:
        db[RESTAURANTS_COLLECTION].update_one({"id": restaurant_id}, {"$set": update})
        r = db[RESTAURANTS_COLLECTION].find_one({"id": restaurant_id})
    return r


@app.post("/restaurants/{restaurant_id}/menu", response_model=MenuItemOut)
def add_menu_item(restaurant_id: int, payload: MenuItemCreate, current=Depends(require_role("restaurant", "admin")), db: Database = Depends(get_db)):
    if not db[RESTAURANTS_COLLECTION].find_one({"id": restaurant_id}):
        raise HTTPException(status_code=404, detail="Restaurant not found")

    item_id = get_next_id(db, MENU_ITEMS_COLLECTION)
    doc = {
        "id": item_id,
        "restaurant_id": restaurant_id,
        "is_available": True,
        **payload.dict(),
    }
    db[MENU_ITEMS_COLLECTION].insert_one(doc)
    return doc


@app.get("/restaurants/{restaurant_id}/menu", response_model=list[MenuItemOut])
def list_menu(restaurant_id: int, db: Database = Depends(get_db)):
    return list(db[MENU_ITEMS_COLLECTION].find({"restaurant_id": restaurant_id}))


@app.put("/menu/{item_id}/availability")
def toggle_availability(item_id: int, is_available: bool, current=Depends(require_role("restaurant", "admin")), db: Database = Depends(get_db)):
    result = db[MENU_ITEMS_COLLECTION].find_one_and_update(
        {"id": item_id}, {"$set": {"is_available": is_available}}
    )
    if not result:
        raise HTTPException(status_code=404, detail="Item not found")
    return {"id": item_id, "is_available": is_available}
