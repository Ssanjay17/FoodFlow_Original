"""
MongoDB collections for the Restaurant Service.

Document shape (collection: "restaurants"):
{
    "id": int,
    "user_id": int | None,
    "name": str,
    "address": str | None,
    "location_lat": float | None,
    "location_lng": float | None,
    "image": str | None,
    "rating": float,
    "created_at": datetime,
}

Document shape (collection: "menu_items"):
{
    "id": int,
    "restaurant_id": int,
    "name": str,
    "description": str | None,
    "price": float,
    "image": str | None,
    "category_id": str | None,
    "is_available": bool,
}
"""
from pymongo.database import Database

RESTAURANTS_COLLECTION = "restaurants"
MENU_ITEMS_COLLECTION = "menu_items"


def ensure_indexes(db: Database):
    db[RESTAURANTS_COLLECTION].create_index("id", unique=True)
    db[RESTAURANTS_COLLECTION].create_index("name")
    db[MENU_ITEMS_COLLECTION].create_index("id", unique=True)
    db[MENU_ITEMS_COLLECTION].create_index("restaurant_id")
