from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class RestaurantCreate(BaseModel):
    name: str
    address: Optional[str] = None
    location_lat: Optional[float] = None
    location_lng: Optional[float] = None
    image: Optional[str] = None

class RestaurantUpdate(BaseModel):
    name: Optional[str] = None
    address: Optional[str] = None
    image: Optional[str] = None

class RestaurantOut(BaseModel):
    id: int
    user_id: Optional[int]
    name: str
    address: Optional[str]
    location_lat: Optional[float]
    location_lng: Optional[float]
    image: Optional[str]
    rating: Optional[float]
    created_at: datetime

    class Config:
        from_attributes = True

class MenuItemCreate(BaseModel):
    name: str
    description: Optional[str] = None
    price: float
    image: Optional[str] = None
    category_id: Optional[str] = None

class MenuItemOut(BaseModel):
    id: int
    restaurant_id: int
    name: str
    description: Optional[str]
    price: float
    image: Optional[str]
    category_id: Optional[str]
    is_available: bool

    class Config:
        from_attributes = True
