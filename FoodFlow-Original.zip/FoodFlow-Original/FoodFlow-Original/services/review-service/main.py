"""
Review Service — Ratings & Reviews (MongoDB-backed, per architecture Data Layer).
Port: 8006
"""
import sys, os
from datetime import datetime
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from fastapi import FastAPI, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional

from shared.auth import get_current_user
from shared.database import get_db

app = FastAPI(title="FoodFlow - Review Service", version="1.0.0")

reviews_col = get_db()["reviews"]


class ReviewCreate(BaseModel):
    order_id: int
    restaurant_id: int
    rating: float
    comment: Optional[str] = None


class ReviewOut(BaseModel):
    order_id: int
    user_id: int
    restaurant_id: int
    rating: float
    comment: Optional[str]
    created_at: str


@app.get("/health")
def health():
    return {"service": "review-service", "status": "ok"}


@app.post("/reviews", response_model=ReviewOut)
def create_review(payload: ReviewCreate, current=Depends(get_current_user)):
    """Order Flow Step 8: customer rates & reviews after delivery."""
    if reviews_col.find_one({"order_id": payload.order_id}):
        raise HTTPException(status_code=400, detail="Review already submitted for this order")

    doc = {
        "order_id": payload.order_id,
        "user_id": int(current["sub"]),
        "restaurant_id": payload.restaurant_id,
        "rating": payload.rating,
        "comment": payload.comment,
        "created_at": datetime.utcnow().isoformat(),
    }
    reviews_col.insert_one(doc)
    doc.pop("_id", None)
    return doc


@app.get("/reviews/restaurant/{restaurant_id}")
def get_restaurant_reviews(restaurant_id: int):
    reviews = list(reviews_col.find({"restaurant_id": restaurant_id}, {"_id": 0}))
    avg_rating = round(sum(r["rating"] for r in reviews) / len(reviews), 1) if reviews else 0
    return {"restaurant_id": restaurant_id, "average_rating": avg_rating, "count": len(reviews), "reviews": reviews}


@app.get("/reviews/order/{order_id}")
def get_order_review(order_id: int):
    review = reviews_col.find_one({"order_id": order_id}, {"_id": 0})
    if not review:
        raise HTTPException(status_code=404, detail="No review found for this order")
    return review
