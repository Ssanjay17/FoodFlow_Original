"""
User Service — Registration, Login, Profile management
Port: 8001
"""
import sys, os
from datetime import datetime
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from fastapi import FastAPI, Depends, HTTPException
from pymongo.database import Database

from shared.database import get_db, get_next_id
from shared.auth import hash_password, verify_password, create_access_token, get_current_user

from models import COLLECTION, ensure_indexes
from schemas import UserRegister, UserLogin, UserOut, UserUpdate, Token

app = FastAPI(title="FoodFlow - User Service", version="1.0.0")
ensure_indexes(get_db())


@app.get("/health")
def health():
    return {"service": "user-service", "status": "ok"}


@app.post("/register", response_model=Token)
def register(payload: UserRegister, db: Database = Depends(get_db)):
    users = db[COLLECTION]
    if users.find_one({"email": payload.email}):
        raise HTTPException(status_code=400, detail="Email already registered")

    user_id = get_next_id(db, COLLECTION)
    doc = {
        "id": user_id,
        "name": payload.name,
        "email": payload.email,
        "phone": payload.phone,
        "password": hash_password(payload.password),
        "role": payload.role or "user",
        "created_at": datetime.utcnow(),
    }
    users.insert_one(doc)

    token = create_access_token({"sub": str(user_id), "email": doc["email"], "role": doc["role"]})
    return {"access_token": token, "user": doc}


@app.post("/login", response_model=Token)
def login(payload: UserLogin, db: Database = Depends(get_db)):
    user = db[COLLECTION].find_one({"email": payload.email})
    if not user or not verify_password(payload.password, user["password"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    token = create_access_token({"sub": str(user["id"]), "email": user["email"], "role": user["role"]})
    return {"access_token": token, "user": user}


@app.get("/me", response_model=UserOut)
def get_me(current=Depends(get_current_user), db: Database = Depends(get_db)):
    user = db[COLLECTION].find_one({"id": int(current["sub"])})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@app.put("/me", response_model=UserOut)
def update_me(payload: UserUpdate, current=Depends(get_current_user), db: Database = Depends(get_db)):
    users = db[COLLECTION]
    user = users.find_one({"id": int(current["sub"])})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    update = {}
    if payload.name:
        update["name"] = payload.name
    if payload.phone:
        update["phone"] = payload.phone
    if update:
        users.update_one({"id": user["id"]}, {"$set": update})
        user.update(update)
    return user


@app.get("/users/{user_id}", response_model=UserOut)
def get_user(user_id: int, db: Database = Depends(get_db)):
    user = db[COLLECTION].find_one({"id": user_id})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@app.get("/users", response_model=list[UserOut])
def list_users(role: str | None = None, db: Database = Depends(get_db)):
    query = {"role": role} if role else {}
    return list(db[COLLECTION].find(query))
