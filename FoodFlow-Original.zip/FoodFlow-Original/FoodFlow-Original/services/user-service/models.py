"""
MongoDB collection for the User Service.

Document shape (collection: "users"):
{
    "id": int,              # auto-increment integer id, see shared.database.get_next_id
    "name": str,
    "email": str,           # unique
    "phone": str | None,
    "password": str,        # bcrypt hash
    "role": str,             # user / restaurant / delivery / admin
    "created_at": datetime,
}
"""
from pymongo.database import Database

COLLECTION = "users"


def ensure_indexes(db: Database):
    db[COLLECTION].create_index("id", unique=True)
    db[COLLECTION].create_index("email", unique=True)
