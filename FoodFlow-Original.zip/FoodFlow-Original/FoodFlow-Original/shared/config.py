"""
Shared configuration loader for all FoodFlow microservices.
Reads from environment variables (.env file), no container assumptions.
"""
import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    # MongoDB — single database for every service (see shared/database.py)
    MONGO_URL = os.getenv("MONGO_URL", "mongodb://localhost:27017")
    MONGO_DB = os.getenv("MONGO_DB", "foodflow")

    # Redis — kept ONLY as the pub/sub message broker for real-time delivery
    # tracking (Section 5). It is a message broker, not a database, so it
    # does not count against the "single MongoDB database" goal.
    REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
    REDIS_PORT = int(os.getenv("REDIS_PORT", 6379))

    # JWT
    JWT_SECRET = os.getenv("JWT_SECRET", "foodflow-dev-secret-change-in-prod")
    JWT_ALGORITHM = "HS256"
    JWT_EXPIRE_MINUTES = 60 * 24

    # Service base URLs (used by API Gateway to route requests)
    USER_SERVICE_URL = os.getenv("USER_SERVICE_URL", "http://localhost:8001")
    RESTAURANT_SERVICE_URL = os.getenv("RESTAURANT_SERVICE_URL", "http://localhost:8002")
    ORDER_SERVICE_URL = os.getenv("ORDER_SERVICE_URL", "http://localhost:8003")
    DELIVERY_SERVICE_URL = os.getenv("DELIVERY_SERVICE_URL", "http://localhost:8004")
    PAYMENT_SERVICE_URL = os.getenv("PAYMENT_SERVICE_URL", "http://localhost:8005")
    REVIEW_SERVICE_URL = os.getenv("REVIEW_SERVICE_URL", "http://localhost:8006")
    NOTIFICATION_SERVICE_URL = os.getenv("NOTIFICATION_SERVICE_URL", "http://localhost:8007")
    OFFER_SERVICE_URL = os.getenv("OFFER_SERVICE_URL", "http://localhost:8008")

settings = Settings()
