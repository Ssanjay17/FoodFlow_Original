"""
Shared MongoDB connection for every FoodFlow service.

FoodFlow now runs on a single MongoDB database — one client, one
database handle, shared by every microservice (each service just uses
its own collection(s) within it). Redis is unaffected: it remains the
pub/sub broker for the delivery-service real-time tracking layer only.

Each service still gets a FastAPI dependency (`get_db`) so route
handlers look the same shape as before, and so tests can override the
dependency with a mongomock database.
"""
from pymongo import MongoClient, ReturnDocument
from pymongo.database import Database
from .config import settings

_client = MongoClient(settings.MONGO_URL)
_db: Database = _client[settings.MONGO_DB]


def get_db() -> Database:
    """FastAPI dependency yielding the shared Mongo database handle."""
    return _db


def get_next_id(db: Database, counter_name: str) -> int:
    """
    Returns the next auto-increment integer id for `counter_name`.

    MongoDB's native _id (ObjectId) isn't a drop-in replacement for the
    small integer ids that flow through JWTs (`sub`) and between
    services (user_id, restaurant_id, order_id, delivery_partner_id,
    etc.), so we keep those ids as plain integers backed by an atomic
    counter, stored in the `counters` collection.
    """
    doc = db["counters"].find_one_and_update(
        {"_id": counter_name},
        {"$inc": {"seq": 1}},
        upsert=True,
        return_document=ReturnDocument.AFTER,
    )
    return doc["seq"]
